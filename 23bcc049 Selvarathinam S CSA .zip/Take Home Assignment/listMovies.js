import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import './MoviesList.css';

export default function MoviesList() {
  const [movies, setMovies] = useState([]);

  useEffect(() => {
    fetch('/api/movies')
      .then(res => res.json())
      .then(data => setMovies(data));
  }, []);

  return (
    <div className="movies-grid">
      {movies.map(m => (
        <Link key={m.id} to={`/movie/${m.id}`} className="movie-card">
          <h3>{m.title}</h3>
          <p>{m.tagline || 'No tagline'}</p>
          <p>Rating: {(m.vote_average || 0).toFixed(1)}/10</p>
        </Link>
      ))}
    </div>
  );
}
