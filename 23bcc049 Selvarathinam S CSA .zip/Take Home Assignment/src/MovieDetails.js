import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

export default function MovieDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [movie, setMovie] = useState(null);

  useEffect(() => {
    fetch(`/api/movies/${id}`)
      .then(res => {
        if (!res.ok) throw new Error('Movie not found');
        return res.json();
      })
      .then(data => setMovie(data))
      .catch(() => setMovie(null));
  }, [id]);

  if (!movie) return <p>Loading or movie not found...</p>;

  const releaseDate = movie.release_date
    ? new Date(movie.release_date).toLocaleDateString()
    : 'N/A';

  const runtime = movie.runtime || 'N/A';

  return (
    <div style={{ padding: '1rem' }}>
      <button onClick={() => navigate(-1)}>Back to list</button>
      <h1>{movie.title}</h1>
      <p><em>{movie.tagline}</em></p>
      <p><strong>Release Date:</strong> {releaseDate}</p>
      <p><strong>Runtime:</strong> {runtime} minutes</p>
      <p><strong>Vote Average:</strong> {(movie.vote_average || 0).toFixed(1)}/10</p>
      <pre>{JSON.stringify(movie, null, 2)}</pre>
    </div>
  );
}
