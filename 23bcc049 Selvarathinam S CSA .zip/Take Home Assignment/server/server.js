const express = require('express');
const app = express();
const port = process.env.PORT || 3001;
const path = require('path');
const fs = require('fs');

const moviesFile = path.join(__dirname, 'movies_metadata.json');
let movies = [];

try {
  const rawData = fs.readFileSync(moviesFile);
  movies = JSON.parse(rawData);
} catch (e) {
  console.error('Failed to load movies:', e);
}

app.use(express.json());

// List movies endpoint
app.get('/api/movies', (req, res) => {
  const list = movies.filter(m => m.id && m.title).map(m => ({
    id: m.id,
    title: m.title,
    tagline: m.tagline,
    vote_average: m.vote_average,
  }));
  res.json(list);
});

// Single movie by ID endpoint
app.get('/api/movies/:id', (req, res) => {
  const movie = movies.find(m => String(m.id) === req.params.id);
  if (!movie) return res.status(404).json({ error: 'Movie not found' });
  res.json(movie);
});

app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});
